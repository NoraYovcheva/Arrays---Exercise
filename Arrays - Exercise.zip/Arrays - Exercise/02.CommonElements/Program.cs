﻿using System;
using System.Linq;

namespace _02.CommonElements
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr1 = Console.ReadLine().Split();
            string[] arr2 = Console.ReadLine().Split();

            foreach (string secondElement in arr2)
            {
                foreach (string firstElement in arr1)
                {
                    if (secondElement == firstElement)
                    {
                        Console.Write($"{secondElement} ");
                    }
                }
            }
        }
    }
}
